#!/bin/bash

if [ -f "/home/config_files/etc/nginx/sites_available/ttm4175" ]; then
    cp /home/config_files/etc/nginx/sites_available/ttm4175 /etc/nginx/sites-available/ttm4175  
    ln -s /etc/nginx/sites-available/ttm4175 /etc/nginx/sites-enabled/ttm4175
fi

if [ -d "/home/config_files/var/www/ttm4175/" ]; then
    mkdir /var/www/ttm4175/
    cp -Tr  --backup=t /home/config_files/var/www/ttm4175/  /var/www/ttm4175/  
fi
