#!/bin/bash

echo "Saving configuration files....."

if [ -d "/var/www/ttm4175/" ]; then
    cp -Tr  --backup=t /var/www/ttm4175/ /home/config_files/var/www/ttm4175/ 
fi

if [ -f "/etc/nginx/sites-available/ttm4175" ]; then
    cp --backup=t /etc/nginx/sites-available/ttm4175 /home/config_files/etc/nginx/sites_available/ttm4175 
fi

