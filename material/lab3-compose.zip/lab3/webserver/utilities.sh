#!/bin/bash

apt-get update && apt-get install -y \
    php-imap php-mbstring php7.2-imap php7.2-mbstring \
    php-net-ldap3 php-intl\
    apt-utils \
    nginx \
    php-fpm \


cp /build/config_files/etc/php/7.2/fpm/php.ini /etc/php/7.2/fpm/php.ini
#default site
cp -Tr /build/config_files/var/www/ttm4175/ /var/www/ttm4175/

cp /build/config_files/etc/nginx/sites_available/default /etc/nginx/sites-available/default







