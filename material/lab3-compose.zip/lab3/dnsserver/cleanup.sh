#!/bin/bash

rm -f /etc/ssh/ssh_host_*
apt-get clean && rm -rf /var/lib/apt/lists/* /tmp/* /var/tmp/*
