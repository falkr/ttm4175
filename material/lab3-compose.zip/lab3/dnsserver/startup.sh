#!/bin/bash

/home/restore.sh


ip route del 0/0
ip route add default via 10.241.1.5
named-checkconf
systemctl enable bind9
service bind9 restart
dpkg-reconfigure openssh-server

echo 'alias python=python3' >> ~/.bashrc
source ~/.bashrc

mkdir ~/.ssh
cat /build/ssh_keys/id_rsa.pub >> /root/.ssh/authorized_keys
cp  /build/ssh_keys/ssh_host* /etc/ssh/
service ssh restart

/bin/bash
