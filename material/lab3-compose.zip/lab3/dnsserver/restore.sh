#!/bin/bash

if [ -f "/home/config_files/etc/bind/ttm4175.com.zone" ]; then
    cp /home/config_files/etc/bind/ttm4175.com.zone /etc/bind/ttm4175.com.zone
fi
if [ -f "/home/config_files/etc/bind/rev-ttm4175.com.zone" ]; then
    cp /home/config_files/etc/bind/rev-ttm4175.com.zone /etc/bind/rev-ttm4175.com.zone
fi
if [ -f "/home/config_files/etc/bind/named.conf.options" ]; then
    cp /home/config_files/etc/bind/named.conf.options /etc/bind/named.conf.options
fi
if [ -f "/home/config_files/etc/bind/named.conf.local" ]; then
    cp /home/config_files/etc/bind/named.conf.local /etc/bind/named.conf.local
fi
