#!/bin/bash

echo "Saving configuration files....."

if [ -f "/etc/bind/ttm4175.com.zone" ]; then
    cp /etc/bind/ttm4175.com.zone /home/config_files/etc/bind/ttm4175.com.zone 
fi

if [ -f "/etc/bind/rev-ttm4175.com.zone" ]; then
    cp /etc/bind/rev-ttm4175.com.zone /home/config_files/etc/bind/rev-ttm4175.com.zone
fi
if [ -f "/etc/bind/named.conf.options" ]; then
    cp /etc/bind/named.conf.options /home/config_files/etc/bind/named.conf.options
fi
if [ -f "/etc/bind/named.conf.local" ]; then
    cp /etc/bind/named.conf.local /home/config_files/etc/bind/named.conf.local
fi







