#!/bin/bash
chmod +x /home/*.sh
/home/startup.sh
/bin/bash





