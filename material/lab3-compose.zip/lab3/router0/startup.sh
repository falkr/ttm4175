#!/bin/bash
VAR=$(ip a | grep 10.241.1.5 | sed 's/.*\(eth*\)/\1/'); ip link set $VAR down; ip link set $VAR name ether1; ip link set ether1 up
VAR=$(ip a | grep 10.168.1.2 | sed 's/.*\(eth*\)/\1/'); ip link set $VAR down; ip link set $VAR name ether0; ip link set ether0 up
ip route del 0/0
ip route add default via 10.168.1.1
dpkg-reconfigure openssh-server
mkdir ~/.ssh
cat /build/ssh_keys/id_rsa.pub >> /root/.ssh/authorized_keys
cp  /build/ssh_keys/ssh_host* /etc/ssh/
service ssh restart

iptables -t nat -A POSTROUTING -o ether0 -j MASQUERADE
iptables -A FORWARD -i ether0 -o ether1 -m state --state RELATED,ESTABLISHED -j ACCEPT
iptables -A FORWARD -i ether1 -o ether0 -j ACCEPT
