#!/bin/bash
rm -f /etc/ssh/ssh_host_*
rm -f /build/*.sh /build/Dockerfile /build/basic.vim
apt-get clean && rm -rf /var/lib/apt/lists/* /tmp/* /var/tmp/*
