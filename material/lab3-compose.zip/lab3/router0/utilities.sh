#!/bin/bash


apt-get update && apt-get install -y \
    curl wget \
    net-tools iputils-ping net-tools iproute2 dnsutils \
    vim nano sudo \
    iptables isc-dhcp-server isc-dhcp-client \
    openssh-server openbsd-inetd traceroute tshark tmux

cp /build/basic.vim ~/.vimrc
mkdir /var/run/sshd
echo 'root:ttm4175' |chpasswd
sed -ri 's/^#?PermitRootLogin\s+.*/PermitRootLogin prohibit-password/' /etc/ssh/sshd_config
sed -ri 's/UsePAM yes/#UsePAM yes/g' /etc/ssh/sshd_config

sed -i '/#net.ipv4.ip_forward=1/c\net.ipv4.ip_forward=1' /etc/sysctl.conf
